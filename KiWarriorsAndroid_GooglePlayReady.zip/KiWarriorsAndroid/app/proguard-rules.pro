# Ki Warriors: no custom ProGuard rules required for the prototype.
