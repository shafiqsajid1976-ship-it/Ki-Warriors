# Ki Warriors — Google Play AAB project

This project wraps the supplied Ki Warriors HTML game in an Android WebView.

## Google Play-ready settings
- Application ID: `com.kiwarriors.app`
- Compile SDK: 36
- Target SDK: 36
- Minimum SDK: 23
- Version code: 2
- Version name: 1.1
- Release build: enabled
- Landscape orientation

## Build an Android App Bundle (.aab)
1. Open this folder in Android Studio.
2. Allow Gradle to sync and install Android SDK Platform 36 if Android Studio asks.
3. Test the app on your Android phone or an emulator.
4. Select **Build → Generate Signed App Bundle / APK**.
5. Choose **Android App Bundle**.
6. Choose **release**.
7. Create/select your upload keystore and finish the wizard.
8. The resulting `.aab` can be uploaded to Google Play Console.

### Important for updates
Keep the same application ID and use a higher version code for every future update. Do not lose the upload keystore. Google Play requires updates to use the same package name and a higher version code, with compatible signing.

### Play Console
For a new release, use **Testing → Internal testing** first, or another appropriate track, then upload the `.aab`. If this is the first release, complete Play App Signing when prompted.

## Notes
The HTML game remains in `app/src/main/assets/index.html`. The Android wrapper does not implement real Google/Apple/Facebook/Instagram OAuth or real subscription payments; those features in the HTML must be implemented with proper services before advertising them as functional.
